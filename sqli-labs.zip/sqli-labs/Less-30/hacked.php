<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<TITLE>Less-30 WAF BYPASS</TITLE>
</HEAD>
<body bgcolor="#000000">
<div style=" margin-top:50px;color:#FFF; font-size:40px; text-align:center"><font color="#FF0000">
<center>
<img src="../images/slap1.jpg">
<br>
<br>
<font size="4">
<a href="login.php">Go Back and Try again</a>
</font>

<br>
<br>
<img src="../images/waf.jpg">
<br>

</center>
</body>
</html>
